
public class Main {
    public static void main(String[] args) {

        // Sample text with names to be replaced
        String text = "Katrine trak sit spørgsmål kl. 10. Katrine fik karakteren 7. Anders trak sit spørgsmål kl. 11. Anders fik karakteren 4";

        // Array of names to be replaced in the text
        String[] names = {"Anders","Katrine","Joakim", "Stine"};

        // Replace names in the text using StringHandler's replaceText method
        String anonymizedText = StringHandler.replaceText(text,names);

        System.out.println(anonymizedText);



        }
    }
