import java.util.List;
import java.util.Arrays;

public class StringHandler {

    // Method to replace specific names in a text with "den studerende"
    public static String replaceText(String text, String[] names) {

        // convert the array(names) to a list
        List<String>nameList=Arrays.asList(names);

//it's used to check each name in a list and perform an action with each one.
        for (String name : nameList){

            //to replace names (with word boundaries) with "den studerende
            text = text.replaceAll("\\b"+ name +"\\b","den studerende ");
        }

        return text;

    }
}



