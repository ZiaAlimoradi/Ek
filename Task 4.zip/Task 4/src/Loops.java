class Loops {

    public static void drawLeftTriangle(int i) {
        for (int j = 1; j <= i; j++) {     // control the number of *
            for (int k = 1; k <= j; k++) { // print *
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void drawRightTriangle(int i) {
        for (int j = 1; j <= i; j++) {  //control the number of *

            for (int l = 1; l <= j; l++) { // print *
                System.out.print("*");
            }
            System.out.println();
        }
    }
}




