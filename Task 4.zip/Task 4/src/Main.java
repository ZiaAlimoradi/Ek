import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        System.out.print("Enter 'R' for right or 'L' for left: ");
        char choice = scanner.next().charAt(0); // first character and char is for using single chapters fx A or  B

        if (choice == 'L') {
            Loops.drawLeftTriangle(num);
        } else if (choice == 'R') {
            Loops.drawRightTriangle(num);
        } else {
            System.out.println("Invalid choice.");
        }
        scanner.close();
    }
}
