import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FoodWaste {
    // Declaration of a list to store category limits
    private List<Integer> limits;

    // Constructor initializing the limits list
    public FoodWaste() {
        this.limits = new ArrayList<>();
    }

    // Method to set the limits for different categories
    public void setLimits(List<Integer> limits) {
        this.limits = limits;
    }

    // Method to check if an item should be placed in the "Stop Madspild" (Stop Food Waste) bin
    public boolean checkDate(int category, LocalDate saleByDate) {
        // Checking if the category index is valid
        if (category >= 0 && category < limits.size()) {
            // Retrieving the limit for the given category
            int categoryLimit = limits.get(category);

            // Calculating the date by subtracting the category limit from the saleByDate
            LocalDate stopFoodWasteDate = saleByDate.minusDays(categoryLimit);
            LocalDate currentDate = LocalDate.now();

            // Checking conditions for Frisk Frugt & Grønt and Fersk Kød categories
            if (category == 0 && currentDate.isBefore(stopFoodWasteDate.plusDays(1))) {
                return true; // Frisk Frugt & Grønt
            } else if (category == 1 && currentDate.isBefore(stopFoodWasteDate)) {
                return true; // Fersk Kød
            }
            return false; // For other categories
        } else {
            System.out.println("Ugyldig kategori!"); // Handling invalid category index
            return false;
        }
    }
}