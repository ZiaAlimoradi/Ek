import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {

    // Main method to test the FoodWaste class
    public static void main(String[] args) {
        FoodWaste foodWaste = new FoodWaste();
        // Initializing limits list for different categories
        List<Integer> limits = new ArrayList<>();
        limits.add(3); // Kategori 0
        limits.add(1); // Kategori 1
        limits.add(14); // Kategori 2
        limits.add(2); // Kategori 3
        limits.add(5); // Kategori 4
        foodWaste.setLimits(limits);

        // Creating a LocalDate object representing the item's saleByDate
        LocalDate saleByDate = LocalDate.of(2024, 1, 10);

        // Testing the checkDate method with different categories to check expected results
        System.out.println("Kategori 0 result: " + foodWaste.checkDate(0, saleByDate)); // Skal returnere true
        System.out.println("Kategori 1 result: " + foodWaste.checkDate(1, saleByDate)); // Skal returnere true
        System.out.println("Kategori 2 result: " + foodWaste.checkDate(2, saleByDate)); // Skal returnere false
        System.out.println("Kategori 3 result: " + foodWaste.checkDate(3, saleByDate)); // Skal returnere false
        System.out.println("Kategori 4 result: " + foodWaste.checkDate(4, saleByDate)); // Skal returnere true
    }
}