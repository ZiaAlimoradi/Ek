public class HourlyEmployee extends Employee {
    private int numberOfHours ;
    private double payPerHours;
    HourlyEmployee ( int numberOfHours, double payPerHours){
        this.numberOfHours=numberOfHours;
        this.payPerHours=payPerHours;
    }
    @Override //It's a way of making sure that the method you're writing in a subclass matches exactly with a method in the parent class.
    public double calculateSalary() {
        return numberOfHours*payPerHours;
    }
}
