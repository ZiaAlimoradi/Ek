 abstract class Employee {


     public abstract double calculateSalary();
 }
