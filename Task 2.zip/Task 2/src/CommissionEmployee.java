public class CommissionEmployee extends Employee{
    private double baseSalary;
    private int sale;
    private double commissions;
    CommissionEmployee (double baseSalary,int sale,double commissions){
        this.baseSalary=baseSalary;
        this.sale= sale;
        this.commissions =commissions;
    }
    @Override
    public double calculateSalary() {
        return baseSalary+(sale*commissions/100);
    }



}
