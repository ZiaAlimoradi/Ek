

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Employee>employees=new ArrayList<>();
        MonthlyEmployee monthlyEmployee= new MonthlyEmployee(5000);
        HourlyEmployee hourlyEmployee = new HourlyEmployee(40,15);
        CommissionEmployee commission = new CommissionEmployee(20000,10000,20);

        employees.add(monthlyEmployee);
        employees.add(hourlyEmployee);
        employees.add(commission);
        for (Employee work : employees){
            System.out.println("Salary: " + work.calculateSalary());
        }








    }
}