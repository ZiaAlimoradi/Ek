import java.util.Scanner;

class HumanPlayer implements Player{

    public int makeAGuess(int maxValue){
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter a number between 1 and  "+ maxValue);
    int guess = scanner.nextInt();
    return guess;

    }


}

