import java.util.Random;

class ComputerPlayer implements Player {

    public int makeAGuess(int maxValue) {
        Random random = new Random();
        return random.nextInt(maxValue)+1;

    }
}
