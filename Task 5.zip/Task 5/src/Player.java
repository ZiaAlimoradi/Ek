 interface Player {


     int makeAGuess(int value) ;

 }



