
public class Main {
    public static void main(String[] args) {
        HumanPlayer humanPlayer= new HumanPlayer();
        ComputerPlayer computerPlayer = new ComputerPlayer();
        int maxValue = 10; // Define the max

        int randomNumber = (int) (Math.random() * maxValue) + 1;

        // Call methods
        int humanGuess = humanPlayer.makeAGuess(maxValue);
        int computerGuess = computerPlayer.makeAGuess(maxValue);
// display the guessing
        System.out.println("The random number is : " + randomNumber);
        System.out.println("Human guessed: " + humanGuess);
        System.out.println("Computer guessed: " + computerGuess);

        if (humanGuess == randomNumber) {
            System.out.println("Human guessed correctly!"+ humanGuess );
        }

        if (computerGuess == randomNumber) {
            System.out.println("Computer guessed correctly!"+computerGuess );
        }
    }
}




