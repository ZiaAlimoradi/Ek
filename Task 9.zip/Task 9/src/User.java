class User {
    private String name;
    private String password;
    private String email;
    private String phoneNumber;

    // Constructor taking name and password as parameters
    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }

    // Constructor taking name, password, and email as parameters
    public User(String name, String password, String email) {
        this(name, password);
        this.email = email;
    }

    // Constructor taking name, password, email, and phoneNumber as parameters
    public User(String name, String password, String email, String phoneNumber) {
        this(name, password, email);
        this.phoneNumber = phoneNumber;
    }

    // Getter and setter methods for all attributes
    public String getName() { // Returns the value of the 'name' attribute
        return name;
    }

    public void setName(String name) { // Sets the 'name' attribute to the provided value
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

// represent the User object as a string, displaying its attributes in a readable format
   //The purpose is to avoid printing attributes that have not been assigned a value
    // toString method to print non-null attributes
    public String toString() { //The toString() method is used to convert the User object into a meaningful string representation
        StringBuilder result = new StringBuilder();
        result.append("Name: ").append(name).append("\n");
        if (password != null) {
            result.append("Password: ").append(password).append("\n");
        }
        if (email != null) {
            result.append("Email: ").append(email).append("\n");
        }
        if (phoneNumber != null) {
            result.append("Phone Number: ").append(phoneNumber).append("\n");
        }
        return result.toString();
    }
}


