public class Main {
    public static void main(String[] args) {
        // Creating User objects using different constructors
        User user1 = new User("John", "pass123");
        User user2 = new User("Alice", "secret", "alice@example.com");
        User user3 = new User("Bob", "bobPass", "bob@example.com", "123456789");

        // Testing toString method
        System.out.println("User 1:\n" + user1.toString());
        System.out.println("User 2:\n" + user2.toString());
        System.out.println("User 3:\n" + user3.toString());
    }
}