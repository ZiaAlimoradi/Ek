public class Item {
    public String name;
    public double price;

    Item ( String name, double price ){
        this.name= name;
        this.price=price;

    }
    @Override
    public String  toString(){ // represent an object and you can get info about the object
        return " Item: " + name + " Price " + price;
    }
}
