public class Main {
    public static void main(String[] args) {
        // Create items
        Item item1 = new Item("Apple", 2.5);
        Item item2 = new Item("Book", 15.0);

        // Create order lines
        OrderLine orderLine1 = new OrderLine(item1, 5);
        OrderLine orderLine2 = new OrderLine(item2, 2);

        // Create an order
        Order order = new Order();
        order.addOrderLine(orderLine1);
        order.addOrderLine(orderLine2);

        // Print the order
        System.out.println(order.toString());
    }
}