import java.util.ArrayList;

class Order {
    ArrayList<OrderLine> orderlines;

    public Order() {
        orderlines = new ArrayList<>();
    }

    public double getTotalPrice() {
        double totalPrice = 0.0; // initialize variables or starting point.
        for (OrderLine orderline : orderlines) { // becuse we have a list
            totalPrice += orderline.getTotalPrice(); // total of the prices for each item
        }
        return totalPrice;
    }

    public void addOrderLine(OrderLine orderline) {
        orderlines.add(orderline); // tilføje ordrelinjer
    }


    //toString() is a method used to represent an object as a string.
    // It provides a way to describe an object's state or information in a human-readable format.
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (OrderLine orderline : orderlines) {
            result.append(orderline.toString()).append("\n");
        }
        result.append("Total Price: ").append(getTotalPrice());
        return result.toString();
    }
}
