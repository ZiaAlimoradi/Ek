class OrderLine {
    Item item;
    int amount;

    public OrderLine(Item item, int amount) {
        this.item = item;
        this.amount = amount;
    }

    public double getTotalPrice() {
        return item.price * amount;
    }

    public String toString() {
        return "OrderLine: " + item.name + ", Amount: " + amount + ", Total Price: " + getTotalPrice();
    }
}
