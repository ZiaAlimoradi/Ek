import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FlowerShop flowerShop = new FlowerShop();

        char choice;
        do {
            flowerShop.runDialog();
            System.out.println("Tast 'Q' for at afslutte eller 'F' for at fortsætte: ");
            choice = scanner.next().charAt(0);
            } while (choice != 'Q');
        }

    }
