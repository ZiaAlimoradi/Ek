import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class FlowerShop {
   private List<String>flowersNames;
    private double total;
    public FlowerShop(){
        flowersNames = new ArrayList<>();
        flowersNames.add("lily");
        flowersNames.add("Rose");
        flowersNames.add("Tulip");
        total=0.0;

    }
    public void presentFlowerList(){
        System.out.println("Prisliste:");
        System.out.println("Blomst 1-4: 20kr");
        System.out.println("Blomst 5-7: 40kr");
        System.out.println("Blomst 8-10: 80kr");
        System.out.println("Buket: 50kr");
    }
    public void runDialog() {
        Scanner scanner = new Scanner(System.in);
        int choices = 0;

        while (choices < 3) { // brugern vælger 3 gange hvis de vil
            presentFlowerList();
            System.out.print("Vælg blomst ved at indtaste tallet: ");
            int flowerChoice = scanner.nextInt();

            if (flowerChoice >= 1 && flowerChoice <= 4) {
                total += 20;
            } else if (flowerChoice >= 5 && flowerChoice <= 7) {
                total += 40;
            } else if (flowerChoice >= 8 && flowerChoice <= 10) {
                total += 80;
            } else {
                System.out.println("Ugyldigt valg. Prøv igen.");
                continue;
            }

            choices++; // hvor mange blomester har brugen vælgt
        }

        System.out.println("Ønsker du at sammensætte en buket? (Ja/Nej)");
        String bouquetChoice = scanner.next();

        if (bouquetChoice.equalsIgnoreCase("Ja")) {
            total += 50;
        }

        System.out.println("Prisen for dine valgte blomster er: " + total + "kr");
    }


}
